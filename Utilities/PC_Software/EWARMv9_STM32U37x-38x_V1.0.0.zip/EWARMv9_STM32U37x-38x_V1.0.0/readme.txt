**
  ************************************************************************************************
  * @file    readme.txt 
  * @author  MCD Application Team
  * @brief   Description of  how to add STM32U37x-38x devices support on EWARM.
  ************************************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  *************************************************************************************************

 Package general purpose:
  ======================================================================================================================	
    These packages contains the needed files to be installed in order to support STM32U37x-38x devices by EWARM9 and laters.

    We inform you that this package is suitable for internal & external use.
	EWARMv9_STM32U37x-38x_V1.0.0.exe has been digitally signed by STMicroelectronics.

  By running the "Install_Patch.bat" file (as an administrator), the following actions will be performed: : 
  ================================================================ 
     1. If you have previously installed an STM32 patch, it will be removed during the first run. 
     
	 2. The following items will be added : 
	  - Part Numbers with 1MB Flash size: STM32U375xG/U385xG.
      - Part Numbers with 512KB Flash size: STM32U375xE.
	  - Automatic STM32U37x-38x flash algorithm selection
	  
     3. The following SVD files will be added: 
	  - STM32U3 SVD file v1r0. 


PS: When using external loader on EWARM, please unselect the verify from the debug menu.The verification is done by the flashloader.
    That you can run EWARMv9_STM32U37x-38x_V1.0.0.exe only if the uninstall is not needed.
	
  How to use:
  ==========
  * Before installing the files mentioned above, you need to have EWARM v9.xx or later installed. 
   
    You can download EWARM from IAR web site @ www.iar.com

  * Run "EWARMv9_STM32U37x-38x_V1.0.0.exe" as administrator at EWARM install directory.
    EWARM Install Directory is "C:\Program Files\IAR Systems\Embedded Workbench \",

  SVD files ReleaseNotes:
  =======================
	=======================================================
	STM32U3_v1r0:     Official release
	=======================================================
	V1.0   First release.